jQuery(document).ready(function(){
	jQuery(function() {
		jQuery('ul.da-thumbs > li').hoverdir();
	});
});